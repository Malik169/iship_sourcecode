# iShip Global

**iShip** is a lightweight shipping website for iPhones, built by Malik Eslam. It supports all iPhone models and lets users ship globally with email confirmation via EmailJS.

## 🌐 Live Demo

[Visit Site](https://iship-global.netlify.app)

## 📦 Features

- Built in HTML + CSS (no frameworks)
- Fully responsive layout
- Integrated with EmailJS to receive shipping orders
- Country-based price table
- Works with any iPhone model

## 🛠 How to Use

1. Replace `YOUR_PUBLIC_KEY`, `YOUR_SERVICE_ID`, and `YOUR_TEMPLATE_ID` in `index.html`.
2. Deploy to Netlify or any static host.
3. Set up your images in the `images/` folder.

## 📁 Folder Structure

```
iship-global/
├── index.html
├── images/
│   ├── iPhone13.jpg
│   └── iPhone14.jpg
```

## 🔓 License

MIT — Free to use and modify, just credit **Malik Eslam**
